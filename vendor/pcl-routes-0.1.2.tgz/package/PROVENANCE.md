# Existing tool runtimes

1. `vendor/hive-cli` is the unmodified `@pcl/hive-cli` source from papercutlabs/hive, commit 9ee691d6cbf075dcd7d1cd940ea81a4f45bd7389. It is bundled at build time; conformance is exported from this package.
2. `vendor/carbon` is the unmodified tools/lib scaffold from papercutlabs/carbon-core, commit 256f704eca2da1fb9c7a7e7e4cbb11eb4297393b. It is distributed with this package and loaded by the generated MCP runtime.
3. Both are PcL internal sources used by permission in PA-351. Third-party runtime dependencies retain their own package licenses.
4. Both are PcL code. Under Teren's ruling that Apache 2.0 is PcL's standard licence (PA-380 comment 56d6bd8e), they ship in this package under its Apache-2.0 licence (LICENSE, copyright Papercut Labs Pte Ltd). The licences of the repositories they were copied from are unchanged here; changing those belongs to those repositories' owners.
5. `./generate` is a generator. It ships in this package only under a temporary exemption (PA-380 comment 95662868) and, while it does, falls under this package's Apache-2.0 licence. It is due to leave the package at the routes split; after that it is private and unlicensed, like PcL's other generators and tools.
