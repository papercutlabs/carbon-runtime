# @pcl/routes

Typed HTTP route helper and generator for PA system interfaces. One declaration produces the HTTP handler, a canonical description, a Hive CLI, a Carbon MCP server, and the API reference.

This package is framework-neutral. Prospaq integration, Linear, and release are owned by the PA-351 delivery lead.

## Install

```bash
pnpm install --frozen-lockfile
pnpm check
```

Runtime dependencies are pinned: TypeBox `0.34.52` and Ajv `8.20.0`. Hive CLI and Carbon MCP sources are vendored; do not edit them.

## Declare routes

```ts
import { Type, defineRoute, describeRoutes, httpHandler } from '@pcl/routes';

const getJob = defineRoute({
  id: 'jobs_get',
  method: 'GET',
  path: '/api/jobs/{id}',
  summary: 'Read one job by id.',
  scope: 'read',
  kind: 'read',
  input: Type.Object({
    id: Type.String({ description: 'Job id, e.g. job_1.' }),
  }),
  output: Type.Object({
    id: Type.String({ description: 'Job id.' }),
    status: Type.String({ description: 'Current status, e.g. open.' }),
  }),
  refusals: [{
    code: 'JOB_NOT_FOUND',
    resolver: 'agent',
    description: 'No job exists with this id.',
    fix: 'Pass an id returned by jobs_list.',
  }],
  run: async (input, ctx) => readJob(input.id, ctx),
});

export const routes = [getJob];
export const description = describeRoutes('app', routes, '1.0.0');
export const handler = httpHandler(routes, authenticate);
```

Write, create, and attach routes must supply `readback`. The HTTP response is the readback value. Input object properties are all required; use explicit null unions for missing values. `action` is a body discriminator and is not an input field.

## Generate caller interfaces

```ts
import { generate, checkGenerated, compatibilityFailures } from '@pcl/routes/generate';

await generate(description, 'generated');
const drift = await checkGenerated(description, 'generated');
const breaking = compatibilityFailures(baseDescription, description);
```

`generate` writes `api.json`, `cli.mjs`, `mcp.mjs`, `tool-server.json`, and `API.md`. Entrypoints load adjacent `api.json` and call `@pcl/routes/cli` or `@pcl/routes/mcp`.

## CLI and MCP

```bash
PCL_API_URL=https://api.example.example PCL_API_TOKEN=… node generated/cli.mjs items-list
PCL_API_URL=https://api.example.example PCL_API_TOKEN=… PCL_API_SCOPES=read PCL_MCP_PORT=8787 node generated/mcp.mjs
```

The bearer token is read from `PCL_API_TOKEN` only. It is never an argv flag. Base URL must be HTTPS, or HTTP on loopback. Redirects are not followed while a bearer credential is held. Each MCP process is one grant; `operator` does not imply `read` or `write`.

Hive conformance helpers are exported from `@pcl/routes/conformance`.

## Public exports

| Module | Exports |
| --- | --- |
| `@pcl/routes` | `Type`, `Static`, `TSchema`, `defineRoute`, `describeRoutes`, `httpHandler`, `validateInput`, `validateOutput`, `RouteFault`, `fail` |
| `@pcl/routes/generate` | `generate`, `checkGenerated`, `compatibilityFailures` |
| `@pcl/routes/cli` | `createCli`, `runCli` |
| `@pcl/routes/mcp` | `createMcp`, `runMcp` |
| `@pcl/routes/conformance` | `conformanceFailures`, `captureCli` |
