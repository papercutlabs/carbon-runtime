# Existing tool runtimes

1. `vendor/hive-cli` is the unmodified `@pcl/hive-cli` source from papercutlabs/hive, commit 9ee691d6cbf075dcd7d1cd940ea81a4f45bd7389. It is bundled at build time; conformance is exported from this package.
2. `vendor/carbon` is the unmodified tools/lib scaffold from papercutlabs/carbon-core, commit 256f704eca2da1fb9c7a7e7e4cbb11eb4297393b. It is distributed with this package and loaded by the generated MCP runtime.
3. Both are PcL internal sources used by permission in PA-351. Third-party runtime dependencies retain their own package licenses.
