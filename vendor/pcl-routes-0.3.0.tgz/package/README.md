# @pcl/routes

Typed HTTP route helper and generator for PA system interfaces. One declaration produces the HTTP handler, a canonical description, a Hive CLI, a Carbon MCP server, and the API reference.

This package is framework-neutral.

**Owner.** `edna-pa-strategy-teren` is the standing owner of this package and its generator (PA-447). Every change to the package is built under an issue that owner accepts, and the owner reviews and merges its pull requests.

## Install

```bash
pnpm install --frozen-lockfile
pnpm check
```

Runtime dependencies are pinned: TypeBox `0.34.52` and Ajv `8.20.0`. Hive CLI and Carbon MCP sources are vendored; do not edit them.

## Declare routes

```ts
import { Type, defineRoute, describeRoutes, httpHandler } from '@pcl/routes';

const getJob = defineRoute({
  id: 'jobs_get',
  method: 'GET',
  path: '/api/jobs/{id}',
  summary: 'Read one job by id.',
  scope: 'read',
  kind: 'read',
  input: Type.Object({
    id: Type.String({ description: 'Job id, e.g. job_1.' }),
  }),
  output: Type.Object({
    id: Type.String({ description: 'Job id.' }),
    status: Type.String({ description: 'Current status, e.g. open.' }),
  }),
  refusals: [{
    code: 'JOB_NOT_FOUND',
    resolver: 'agent',
    description: 'No job exists with this id.',
    fix: 'Pass an id returned by jobs_list.',
  }],
  run: async (input, ctx) => readJob(input.id, ctx),
});

export const routes = [getJob];
export const description = describeRoutes('app', routes, '1.0.0');
export const handler = httpHandler(routes, authenticate);
```

Write, create, and attach routes must supply `readback`. The HTTP response is the readback value. Input object properties are all required; use explicit null unions for missing values. `action` is a body discriminator and is not an input field.

## File routes

A read route can answer with a file instead of JSON (PA-446). It declares `file` in place of `output`, and its `run` returns the file:

```ts
export const summaryCsv = defineRoute({
  id: 'summary_download',
  method: 'GET',
  path: '/api/summary.csv',
  summary: 'Download the summary as CSV.',
  scope: 'read',
  kind: 'read',
  input: Type.Object({ day: Type.String({ description: 'Day, e.g. 2026-11-01.' }) }),
  refusals: [],
  file: { mediaTypes: ['text/csv'], disposition: 'attachment', description: 'One line per product.' },
  run: async (input) => ({ fileName: `summary-${input.day}.csv`, mediaType: 'text/csv; charset=utf-8', body: bytesOrStreamOrAsyncIterable }),
});
```

1. A file route is a GET read with at least one bare media type (`type/subtype`, no parameters). One with none is refused by `defineRoute`, `describeRoutes` and `fileDeclarationFailures`.
2. The server answers 200 with the body, its `content-type`, an RFC 6266 `content-disposition` and `nosniff`. A web stream or async iterable body is pulled one chunk per read, so a large file is never held whole. A media type the route did not declare is refused as a JSON fault before any byte leaves; input, auth and scope refusals stay JSON.
3. The generated CLI requires `--out <path>`. It streams to a partial file beside the path and renames it into place only once whole.
4. The generated MCP returns the file as one embedded blob resource (`{type: 'resource', resource: {uri, mimeType, blob}}`), with `fileName`, `mediaType` and `bytes` as structured content. MCP carries a blob as base64 in the message, so this path holds the file once; the CLI is the route for very large files.
5. `@pcl/routes/conformance` exports `fileDeclarationFailures(description)`, `fileResponseFailures(operation, response)` and `openFile(operation, input, options)`.
6. JSON routes are unchanged byte for byte: `tests/fixtures/json-responses-0.1.0.json` is a walk taken on 0.1.0 and replayed on every test run.

## Generate caller interfaces

```ts
import { generate, checkGenerated, compatibilityFailures } from '@pcl/routes/generate';

await generate(description, 'generated');
const drift = await checkGenerated(description, 'generated');
const breaking = compatibilityFailures(baseDescription, description);
```

`generate` writes `api.json`, `cli.mjs`, `mcp.mjs`, `tool-server.json`, and `API.md`. Entrypoints load adjacent `api.json` and call `@pcl/routes/cli` or `@pcl/routes/mcp`.

## CLI and MCP

```bash
PCL_API_URL=https://api.example.example PCL_API_TOKEN=… node generated/cli.mjs items-list
PCL_API_URL=https://api.example.example PCL_API_TOKEN=… PCL_API_SCOPES=read PCL_MCP_PORT=8787 node generated/mcp.mjs
```

The bearer token is read from `PCL_API_TOKEN` only. It is never an argv flag. Base URL must be HTTPS, or HTTP on loopback. Redirects are not followed while a bearer credential is held. Each MCP process is one grant; `operator` does not imply `read` or `write`.

Hive conformance helpers are exported from `@pcl/routes/conformance`.

## The route check

`pcl-routes check` fails a repository that answers an HTTP request outside the typed-route system, wherever the code sits. It finds:

1. every `route.{ts,tsx,js,mjs}` under an `app` directory at any depth, and pages-router files under `pages/api`, unless the file exports each HTTP method as a `const` bound to the typed handler;
2. `middleware` (and root `proxy`) files that return a response;
3. any module with a `'use server'` directive, at module or function level;
4. any module that creates a server with `node:http`, `node:https`, `node:http2`, `Bun.serve` or `Deno.serve`, or imports a server framework (express, fastify, koa, hono, restify, polka, hapi), outside the serve adapter.

Tests, `node_modules`, build output and `generated/` are not scanned. The route set is read from the build's generated `api.json`, never from a second list: a Next handler with no operation, or an operation with no Next handler, fails.

`pcl-routes.json` at the repository root configures it:

```json
{
  "description": ["generated/api.json"],
  "handlerModules": ["@/lib/routes/http"],
  "exceptions": [{ "file": "src/app/export/[file]/route.ts", "kind": "next-route", "reason": "Signed installer file the package cannot type yet." }]
}
```

An exception names a file, the kind of finding it covers (`next-route`, `pages-api`, `middleware`, `server-action`, `node-server` or `framework-server`) and a written reason; it covers only that kind in that file. The check prints every one. An exception that matches nothing fails, so exceptions do not outlive their cause. If exceptions accumulate, the owner adds the missing capability here instead of approving them one by one.

**Compatibility.** `pcl-routes release` records the generated description as `generated/api.released.json` beside it and refuses a description that breaks the previous release. From then on `check` fails any change that breaks it (the package's existing compatibility rules); before the first release it passes. In CI, pass `--base <rev>` so the released description is read from the base branch and a pull request cannot loosen it by editing the file. There is no per-app switch.

**CI.** Use the action: `uses: papercutlabs/pcl-routes/check@v0.3.0` after `actions/checkout` with `fetch-depth: 0`. It is bundled with its dependencies in `check/index.cjs`, so a caller needs no install, no vendored tarball and no secret; the check's version is the tag. `.github/workflows/check.yml` wraps it for a repo to call or for the organisation rule. The bundle is rebuilt by `pnpm build`, and package CI fails if the committed copy is stale.

## Serve a Node build

`@pcl/routes/serve` provides `createNodeServer({ routes, authenticate, staticFiles })`. It answers typed routes and the exact paths listed in `staticFiles` (GET and HEAD only), and nothing else, so a Node build has no dispatch of its own.

## Public exports

| Module | Exports |
| --- | --- |
| `@pcl/routes` | `Type`, `Static`, `TSchema`, `FILE_OUTPUT`, `defineRoute`, `describeRoutes`, `httpHandler`, `validateInput`, `validateOutput`, `RouteFault`, `fail` |
| `@pcl/routes/generate` | `generate`, `checkGenerated`, `compatibilityFailures` |
| `@pcl/routes/serve` | `createNodeServer` |
| `@pcl/routes/check` | `check`, `release` |
| `@pcl/routes/cli` | `createCli`, `runCli` |
| `@pcl/routes/mcp` | `createMcp`, `runMcp` |
| `@pcl/routes/conformance` | `conformanceFailures`, `captureCli`, `fileDeclarationFailures`, `fileResponseFailures`, `openFile` |
